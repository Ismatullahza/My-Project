-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 13 Jan 2024 pada 07.25
-- Versi server: 10.4.19-MariaDB
-- Versi PHP: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbalatberat`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_admin`
--

CREATE TABLE `tb_admin` (
  `id_admin` int(11) NOT NULL,
  `username` varchar(60) NOT NULL,
  `password` varchar(80) NOT NULL,
  `nama_lengkap` varchar(60) NOT NULL,
  `nohp` varchar(16) NOT NULL,
  `level` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tb_admin`
--

INSERT INTO `tb_admin` (`id_admin`, `username`, `password`, `nama_lengkap`, `nohp`, `level`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'ADMIN', '6283356703134', 'admin'),
(2, 'user', 'ee11cbb19052e40b07aac0ca060c23ee', 'USER', '6281274356890', 'user');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_alat_berat`
--

CREATE TABLE `tb_alat_berat` (
  `id_alatberat` int(11) NOT NULL,
  `nama_alatberat` varchar(60) NOT NULL,
  `deskripsi` text NOT NULL,
  `jumlah_alatberat` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `gambar_alatberat` text NOT NULL,
  `jml_pinjam` int(11) NOT NULL,
  `jml_perbaiki` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tb_alat_berat`
--

INSERT INTO `tb_alat_berat` (`id_alatberat`, `nama_alatberat`, `deskripsi`, `jumlah_alatberat`, `harga`, `gambar_alatberat`, `jml_pinjam`, `jml_perbaiki`) VALUES
(1, 'Excavator', '-', 5, 1000000, 'istockphoto-1745180120-612x612.jpg', 0, 0),
(2, 'Bulldozer', '-', 5, 1100000, 'istockphoto-1495665798-612x612.jpg', 0, 0),
(3, 'Tractor', '-', 3, 900000, 'istockphoto-903469538-612x612.jpg', 0, 0),
(4, 'Compactor', '-', 5, 1500000, 'compactor-3248717_1280.jpg', 0, 1),
(5, 'Dump Truck', '-', 3, 2000000, 'dump-truck-3080177_1280.jpg', 1, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_denda`
--

CREATE TABLE `tb_denda` (
  `id_denda` int(11) NOT NULL,
  `harga_denda` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tb_denda`
--

INSERT INTO `tb_denda` (`id_denda`, `harga_denda`) VALUES
(1, 10000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_peminjam`
--

CREATE TABLE `tb_peminjam` (
  `id_peminjam` int(11) NOT NULL,
  `nama_peminjam` varchar(60) NOT NULL,
  `nohp` varchar(15) NOT NULL,
  `email` varchar(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tb_peminjam`
--

INSERT INTO `tb_peminjam` (`id_peminjam`, `nama_peminjam`, `nohp`, `email`) VALUES
(5, 'Pak Karmi', '6282245786990', 'karmi@gmail.com'),
(6, 'Pak Dandi', '6283845608987', 'dandi@gmail.com'),
(7, 'Buk Cindi', '6282238509877', 'cindi@gmail.com'),
(8, 'Dodi', '6283380592085', 'dodi@gmail.com'),
(9, 'Fajar', '628225708976', 'fajar@gmail.com');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_pengembalian`
--

CREATE TABLE `tb_pengembalian` (
  `id_kembali` int(11) NOT NULL,
  `idpinjam` int(11) NOT NULL,
  `tglkembali` date NOT NULL,
  `kondisi_alatberat` varchar(60) NOT NULL,
  `catatan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tb_pengembalian`
--

INSERT INTO `tb_pengembalian` (`id_kembali`, `idpinjam`, `tglkembali`, `kondisi_alatberat`, `catatan`) VALUES
(1, 3, '2024-01-15', 'Baik', 'ALat Berat Kondisi Baik'),
(2, 4, '2024-01-13', '', ''),
(3, 5, '2024-01-13', 'Baik', 'Alat Berat Keadaan Baik'),
(4, 6, '2024-01-12', 'Rusak', 'Harus Diperbaiki'),
(5, 7, '2024-01-13', 'Rusak', 'Segera Diperbaiki');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_sewa`
--

CREATE TABLE `tb_sewa` (
  `id_sewa` int(11) NOT NULL,
  `idalat` int(11) NOT NULL,
  `idpeminjam` int(11) NOT NULL,
  `jumlah_pinjam` int(11) NOT NULL,
  `harga_alat` int(11) NOT NULL,
  `harga_total_perhari` int(11) NOT NULL,
  `hari` int(11) NOT NULL,
  `tgLpinjam` date NOT NULL,
  `tgl_kembali` date NOT NULL,
  `harga_total_pinjam` int(11) NOT NULL,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tb_sewa`
--

INSERT INTO `tb_sewa` (`id_sewa`, `idalat`, `idpeminjam`, `jumlah_pinjam`, `harga_alat`, `harga_total_perhari`, `hari`, `tgLpinjam`, `tgl_kembali`, `harga_total_pinjam`, `status`) VALUES
(3, 4, 5, 2, 1500000, 6000000, 4, '2024-01-11', '2024-01-15', 12000000, 2),
(4, 5, 6, 1, 2000000, 4000000, 2, '2024-01-11', '2024-01-13', 4000000, 1),
(5, 2, 7, 1, 1100000, 2200000, 2, '2024-01-11', '2024-01-13', 2200000, 2),
(6, 2, 8, 1, 1100000, 1100000, 1, '2024-01-11', '2024-01-12', 1100000, 2),
(7, 4, 9, 1, 1500000, 3000000, 2, '2024-01-11', '2024-01-13', 3000000, 2);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tb_admin`
--
ALTER TABLE `tb_admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indeks untuk tabel `tb_alat_berat`
--
ALTER TABLE `tb_alat_berat`
  ADD PRIMARY KEY (`id_alatberat`);

--
-- Indeks untuk tabel `tb_denda`
--
ALTER TABLE `tb_denda`
  ADD PRIMARY KEY (`id_denda`);

--
-- Indeks untuk tabel `tb_peminjam`
--
ALTER TABLE `tb_peminjam`
  ADD PRIMARY KEY (`id_peminjam`);

--
-- Indeks untuk tabel `tb_pengembalian`
--
ALTER TABLE `tb_pengembalian`
  ADD PRIMARY KEY (`id_kembali`);

--
-- Indeks untuk tabel `tb_sewa`
--
ALTER TABLE `tb_sewa`
  ADD PRIMARY KEY (`id_sewa`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tb_admin`
--
ALTER TABLE `tb_admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `tb_alat_berat`
--
ALTER TABLE `tb_alat_berat`
  MODIFY `id_alatberat` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `tb_denda`
--
ALTER TABLE `tb_denda`
  MODIFY `id_denda` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `tb_peminjam`
--
ALTER TABLE `tb_peminjam`
  MODIFY `id_peminjam` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT untuk tabel `tb_pengembalian`
--
ALTER TABLE `tb_pengembalian`
  MODIFY `id_kembali` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `tb_sewa`
--
ALTER TABLE `tb_sewa`
  MODIFY `id_sewa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
