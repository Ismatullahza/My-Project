<?php
// Koneksi ke database
include 'koneksi.php';

// Mendapatkan ID alat berat dari parameter GET
$id_alat = $_GET['id'];

// Mengambil data harga dari database berdasarkan ID alat berat
$query = "SELECT harga FROM tb_alat_berat WHERE id_alatberat = $id_alat";
$result = mysqli_query($koneksi, $query);
$data = mysqli_fetch_assoc($result);

// Mengembalikan data dalam format JSON
echo json_encode($data);
?>