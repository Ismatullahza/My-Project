<?php
// Koneksi ke database
include 'koneksi.php';

// Nilai yang akan diupdate
$id_alat = $_POST['ida'];
$jumlah_alatberat = $_POST['jmla']; // Ganti dengan nilai yang sesuai
$jumlah = $_POST['jmlp']; // Ganti dengan nilai yang sesuai
$status = $_POST['status'];

if ($status == 'Selesai') {
    // Query SQL untuk melakukan update
    $sql = "UPDATE tb_alat_berat SET jumlah_alatberat = jumlah_alatberat + $jumlah, jml_perbaiki = jml_perbaiki - $jumlah WHERE id_alatberat = $id_alat";
}

// Eksekusi query
if ($koneksi->query($sql) === TRUE) {
    echo "<script>alert('Alat Berat Diperbaiki Sudah Selesai.'); document.location='alat_berat.php';</script>";
} else {
    echo "Error updating record: " . $koneksi->error;
}

// Tutup koneksi
$koneksi->close();
?>