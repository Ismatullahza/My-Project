<?php 
session_start();
include 'koneksi.php';
if (!isset($_SESSION['login_type'])) {
    // Redirect to login page with SweetAlert2 alert
    echo "<script>alert('Anda Tidak Berhak Masuk, Login Terlebih Dahulu.'); document.location='../index.php';</script>";
    exit();
}

$data = mysqli_query($koneksi, "SELECT * FROM tb_denda");
$d = mysqli_fetch_assoc($data);
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Alat Berat - Tabel Denda</title>

    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php include 'menu.php'; ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include 'navbar.php'; ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Tabel Denda</h1>
                    
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <a class="btn btn-warning" href="" data-toggle="modal" data-target="#dendaModal<?php echo $d['id_denda']; ?>"><i class="fas fa-edit"></i> Update Harga Denda</a>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No.</th>
                                            <th>Nama Penyewa</th>
                                            <th>Nama Alat Berat</th>
                                            <th>Tgl. Sewa</th>
                                            <th>Tgl. Kembali</th>
                                            <th>Selisih Hari</th>
                                            <th>Denda per Hari</th>
                                            <th>Total Denda</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $no = 1;

                                        $sql = "SELECT * FROM tb_sewa, tb_peminjam, tb_alat_berat WHERE idpeminjam = id_peminjam AND idalat = id_alatberat ORDER BY id_sewa ASC"; // Ganti 1 dengan ID sewa yang sesuai
                                        $result = $koneksi->query($sql);
                                        while ($row = $result->fetch_assoc()) {
                                            $tgl_pinjam = $row['tgLpinjam'];
                                            $tgl_kembali = $row['tgl_kembali'];

                                            // Hitung selisih hari
        $selisih_hari = strtotime($tgl_kembali) - strtotime($tgl_pinjam);
        $selisih_hari = floor($selisih_hari / (60 * 60 * 24));

        // Tentukan denda per hari
        $denda_per_hari = $d['harga_denda'];

        // Hitung total denda
        $total_denda = ($selisih_hari > 0) ? $selisih_hari * $denda_per_hari : 0;
                                        ?>
                                        <tr>
                                            <td><?php echo $no++; ?>.</td>
                                            <td><?php echo $row['nama_peminjam']; ?></td>
                                            <td><?php echo $row['nama_alatberat']; ?></td>
                                            <td><?php echo $tgl_pinjam; ?></td>
                                            <td><?php echo $tgl_kembali; ?></td>
                                            <td><?php echo $selisih_hari; ?> Hari</td>
                                            <td><?php echo "Rp. " .number_format($denda_per_hari). ",-"; ?></td>
                                            <td>
                                                <?php 
                                                // Check if the return date has passed
                                                if (strtotime($tgl_kembali) < time()) {
                                                    // Check if the heavy equipment has been returned
                                                    if ($row['status'] == 2) {
                                                        echo "<span class='badge badge-success'>Alat Berat Sudah Kembali</span>";
                                                    } else {
                                                        echo "Rp. " . number_format($total_denda) . ",-";
                                                    }
                                                } else {
                                                    echo "<span class='badge badge-primary'>Belum Selesai Disewa</span>";
                                                }
                                                ?>
                                            </td>
                                        </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

                <!-- Modal -->
                <?php 
                $d = mysqli_query($koneksi, "SELECT * FROM tb_denda");
                while ($rd = mysqli_fetch_assoc($d)){
                ?>
                <div class="modal" id="dendaModal<?php echo $rd['id_denda']; ?>" tabindex="-1" role="dialog" aria-labelledby="dendaModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="dendaModalLabel">Update Harga Denda</h5>
                          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                          </button>
                        </div>
                        <div class="modal-body">
                          <!-- Isi Form Denda -->
                          <form method="POST" action="update_denda.php">
                            <input type="hidden" name="id_denda" value="<?php echo $rd['id_denda']; ?>">
                            <div class="form-group">
                              <label for="hargaDenda">Harga Denda</label>
                              <input type="text" class="form-control" id="hargaDenda" name="hargaDenda" placeholder="Masukkan Harga Denda" value="<?php echo $rd['harga_denda']; ?>">
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                                <button type="submit" class="btn btn-primary">Update</button>
                            </div>
                          </form>
                        </div>
                    </div>
                </div>
            </div>
            <?php } ?>

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Amelia Putri 2020</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="keluar.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/datatables-demo.js"></script>

</body>

</html>