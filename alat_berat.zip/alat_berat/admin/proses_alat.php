<?php
// Koneksi ke database
include 'koneksi.php';

// Tangkap data dari formulir
$nama_alatberat = $_POST['nama'];
$deskripsi = $_POST['deskripsi'];
$jumlah_alatberat = $_POST['jumlah'];
$harga = $_POST['harga'];

// Upload gambar
$gambar = $_FILES['filealat']['name'];
$gambar_tmp = $_FILES['filealat']['tmp_name'];
$upload_dir = "alatberat/"; // Sesuaikan dengan direktori tempat gambar diunggah

// Pindahkan gambar ke direktori tujuan
move_uploaded_file($gambar_tmp, $upload_dir . $gambar);

// Query untuk menyimpan data baru ke dalam tabel
$sql = "INSERT INTO tb_alat_berat (nama_alatberat, deskripsi, jumlah_alatberat, harga, gambar_alatberat) 
        VALUES ('$nama_alatberat', '$deskripsi', '$jumlah_alatberat', '$harga', '$gambar')";

if ($koneksi->query($sql) === TRUE) {
    echo "<script>alert('Data berhasil disimpan.'); document.location='alat_berat.php';</script>";
} else {
    echo "Error: " . $sql . "<br>" . $koneksi->error;
}

// Tutup koneksi
$koneksi->close();
?>