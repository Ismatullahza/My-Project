<?php
// Include your database connection file here
include('koneksi.php');

// Get values from the form
$username = $_POST['username'];
$password = md5($_POST['password']); // Use a more secure hashing algorithm in production
$nama_lengkap = $_POST['nama'];
$nohp = $_POST['nohp'];
$level = $_POST['level'];

// SQL query to insert data into tb_admin
$sql = "INSERT INTO tb_admin (username, password, nama_lengkap, nohp, level) 
        VALUES ('$username', '$password', '$nama_lengkap', '$nohp', '$level')";

// Execute the query
if ($koneksi->query($sql) === TRUE) {
    echo "<script>alert('Data berhasil disimpan.'); document.location='pengguna.php';</script>";
} else {
    echo "Error: " . $sql . "<br>" . $koneksi->error;
}

// Close the database koneksiection
$koneksi->close();
?>