<?php
// Koneksi ke database
include 'koneksi.php';

// Mendapatkan data untuk update dari formulir atau sumber lainnya
$id_sewa = $_POST['ids'];
$id_alat = $_POST['id_alat'];
$jumlah_alatberat = $_POST['jumlah'];
$status_sewa = $_POST['status'];
$kondisi_alatberat = $_POST['statusAlatBerat'];
$catatan = $_POST['catatan'];

// Update tabel tb_sewa
$sql_tb_sewa = "UPDATE tb_sewa SET status = '$status_sewa' WHERE id_sewa = '$id_sewa'";
$result_tb_sewa = $koneksi->query($sql_tb_sewa);

if ($kondisi_alatberat == 'Baik') {
    // Update tabel tb_alat_berat
    $sql_tb_alat_berat = "UPDATE tb_alat_berat SET jumlah_alatberat = jumlah_alatberat + $jumlah_alatberat, jml_pinjam = jml_pinjam - $jumlah_alatberat WHERE id_alatberat = '$id_alat'";
    $result_tb_alat_berat = $koneksi->query($sql_tb_alat_berat);
}elseif ($kondisi_alatberat =='Rusak') {
    // Update tabel tb_alat_berat
    $sql_tb_alat_berat = "UPDATE tb_alat_berat SET jml_pinjam = jml_pinjam - $jumlah_alatberat, jml_perbaiki = jml_perbaiki + $jumlah_alatberat WHERE id_alatberat = '$id_alat'";
    $result_tb_alat_berat = $koneksi->query($sql_tb_alat_berat);
}

// Update tabel tb_pengembalian
$sql_tb_pengembalian = "UPDATE tb_pengembalian SET kondisi_alatberat = '$kondisi_alatberat', catatan = '$catatan' WHERE idpinjam = '$id_sewa'";
$result_tb_pengembalian = $koneksi->query($sql_tb_pengembalian);

// Periksa apakah update berhasil
if ($result_tb_sewa && $result_tb_alat_berat && $result_tb_pengembalian) {
    echo "<script>alert('Data berhasil diperbarui.'); document.location='sewa.php';</script>";
} else {
    echo "Terjadi kesalahan saat memperbarui data: " . $koneksi->error;
}

// Tutup koneksi ke database
$koneksi->close();
?>