<?php 
$host = "localhost";
$user = "root";
$pass = "";
$db = "dbalatberat";

$koneksi = new mysqli($host, $user, $pass, $db);

?>