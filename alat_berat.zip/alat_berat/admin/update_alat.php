<?php
// Koneksi ke database
include 'koneksi.php';

// Tangkap data dari formulir
$id_alatberat = $_POST['id_alatberat']; // Diambil dari formulir atau parameter URL
$nama_alatberat = $_POST['nama'];
$deskripsi = $_POST['deskripsi'];
$jumlah_alatberat = $_POST['jumlah'];
$harga = $_POST['harga'];

// Periksa apakah gambar baru diunggah
if ($_FILES['filealat']['size'] > 0) {
    // Upload gambar baru
    $gambar = $_FILES['filealat']['name'];
    $gambar_tmp = $_FILES['filealat']['tmp_name'];
    $upload_dir = "alatberat/"; // Sesuaikan dengan direktori tempat gambar diunggah

    // Pindahkan gambar ke direktori tujuan
    move_uploaded_file($gambar_tmp, $upload_dir . $gambar);

    // Update data dengan gambar baru
    $sql = "UPDATE tb_alat_berat 
            SET nama_alatberat='$nama_alatberat', deskripsi='$deskripsi', jumlah_alatberat='$jumlah_alatberat', harga='$harga', gambar_alatberat='$gambar'
            WHERE id_alatberat=$id_alatberat";
} else {
    // Update data tanpa mengubah gambar
    $sql = "UPDATE tb_alat_berat 
            SET nama_alatberat='$nama_alatberat', deskripsi='$deskripsi', jumlah_alatberat='$jumlah_alatberat', harga='$harga'
            WHERE id_alatberat=$id_alatberat";
}

if ($koneksi->query($sql) === TRUE) {
    echo "<script>alert('Data berhasil diperbarui.'); document.location='alat_berat.php';</script>";
} else {
    echo "Error: " . $sql . "<br>" . $koneksi->error;
}

// Tutup koneksi
$koneksi->close();
?>