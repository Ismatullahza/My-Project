<?php 
session_start();
include 'koneksi.php';
if (!isset($_SESSION['login_type'])) {
    // Redirect to login page with SweetAlert2 alert
    echo "<script>alert('Anda Tidak Berhak Masuk, Login Terlebih Dahulu.'); document.location='../index.php';</script>";
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Alat Berat - Tabel Sewa Alat Berat</title>

    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php include 'menu.php'; ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include 'navbar.php'; ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Tabel Sewa Alat Berat</h1>
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <a class="btn btn-primary" href="tambah_pinjam.php"><i class="fas fa-plus"></i> Tambah Data</a>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No.</th>
                                            <th>Nama alat Berat</th>
                                            <th>Nama Penyewa</th>
                                            <th>Jumlah Sewa</th>
                                            <th>Harga Sewa</th>
                                            <th>Berapa Hari</th>
                                            <th>Tgl. Sewa</th>
                                            <th>Tgl. Kembali</th>
                                            <th>Total Harga</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php 
                                        $no = 1; 

                                        $data = mysqli_query($koneksi, "SELECT * FROM tb_sewa, tb_alat_berat, tb_peminjam WHERE idalat = id_alatberat AND idpeminjam = id_peminjam ORDER BY id_sewa DESC");
                                        while ($row = mysqli_fetch_assoc($data)){
                                        ?>
                                        <tr>
                                            <td><?php echo $no++; ?></td>
                                            <td><?php echo $row['nama_alatberat']; ?></td>
                                            <td><?php echo $row['nama_peminjam']; ?></td>
                                            <td><?php echo $row['jumlah_pinjam']; ?> alat berat</td>
                                            <td><?php echo "Rp. " .number_format($row['harga_alat']). ",-"; ?></td>
                                            <td><?php echo $row['hari']; ?> Hari</td>
                                            <td><?php echo $row['tgLpinjam']; ?></td>
                                            <td><?php echo $row['tgl_kembali']; ?></td>
                                            <td><?php echo "Rp. " .number_format($row['harga_total_pinjam']). ",-"; ?></td>
                                            <td>
                                                <?php if ($row['status'] == 1) { ?>
                                                    <span class="badge badge-primary">Sewa</span>
                                                <?php }elseif ($row['status'] == 2) { ?>
                                                    <span class="badge badge-success">Kembali</span>
                                                <?php } ?>
                                            </td>
                                            <td align="center">
                                                <?php if ($row['status'] == 1) { ?>
                                                    <a class="btn btn-sm btn-warning" href="" data-toggle="modal" data-target="#myModal<?php echo $row['id_sewa']; ?>"><i class="fas fa-info-circle"></i></a>
                                                <?php }elseif ($row['status'] == 2) { ?>
                                                    <span class="badge badge-success">Alat berat kembali</span>
                                                <?php } ?>
                                            </td>
                                        </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            <!-- Modal -->
            <?php 
            $s = mysqli_query($koneksi, "SELECT * FROM tb_sewa, tb_alat_berat WHERE idalat = id_alatberat");
            while ($rs = mysqli_fetch_assoc($s)){
            ?>
            <div class="modal" id="myModal<?php echo $rs['id_sewa']; ?>">
                <div class="modal-dialog">
                    <div class="modal-content">

                    <!-- Bagian Header Modal -->
                    <div class="modal-header">
                        <h4 class="modal-title">Status Alat Berat</h4>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>

                    <!-- Bagian Body Modal -->
                    <div class="modal-body">
                        <!-- Formulir -->
                        <form method="POST" action="update_sewa.php">
                            <input type="hidden" name="ids" value="<?php echo $rs['id_sewa']; ?>">
                            <input type="hidden" name="jumlah" value="<?php echo $rs['jumlah_pinjam']; ?>">
                            <input type="hidden" name="id_alat" value="<?php echo $rs['id_alatberat']; ?>">
                            <!-- Formulir Select (Dropdown) -->
                            <div class="form-group">
                                <label for="toggle">Status Sewa:</label>
                                <select class="form-control" id="status" name="status">
                                    <option selected disabled>Pilih Status Sewa</option>
                                    <option value="2">Kembali</option>
                                </select>
                            </div>

                            <!-- Formulir Select (Dropdown) -->
                            <div class="form-group">
                                <label for="statusSelect">Kondisi Alat Berat:</label>
                                <select class="form-control" id="statusSelect" name="statusAlatBerat">
                                    <option selected disabled>Pilih Kondisi Alat Berat</option>
                                  <option value="Baik">Baik</option>
                                  <option value="Rusak">Rusak</option>
                                </select>
                            </div>

                            <!-- Formulir Catatan -->
                            <div class="form-group">
                                <label for="catatan">Catatan:</label>
                                <textarea class="form-control" id="catatan" name="catatan" rows="3"></textarea>
                            </div>

                            <!-- Tombol Simpan -->
                            <button type="submit" class="btn btn-primary">Update</button>
                        </form>
                    </div>

                    <!-- Bagian Footer Modal -->
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                    </div>

                </div>
            </div>
        </div>
        <?php } ?>

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Amelia Putri 2020</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="keluar.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/datatables-demo.js"></script>

</body>

</html>