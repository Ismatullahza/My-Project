<?php 
session_start();
include 'koneksi.php';
if (!isset($_SESSION['login_type'])) {
    // Redirect to login page with SweetAlert2 alert
    echo "<script>alert('Anda Tidak Berhak Masuk, Login Terlebih Dahulu.'); document.location='../index.php';</script>";
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Alat Berat - Tabel Laporan</title>

    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php include 'menu.php'; ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php include 'navbar.php'; ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Tabel Laporan</h1>
                    
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <form method="GET">
                                <div class="row">
                                    <div class="form-group col-md-3">
                                      <label>Dari Tanggal Sewa</label>
                                      <input type="date" class="form-control" id="sewa" name="sewa">  
                                    </div>

                                    <div class="form-group col-md-3">
                                      <label>Sampai Tanggal Kembali</label>
                                      <input type="date" class="form-control" id="kembali" name="kembali">  
                                    </div>

                                    <div class="form-group col-md-3">
                                      <label>Status</label>
                                      <select class="form-control" id="status" name="status">
                                          <option selected disabled>Pilih Status</option>
                                          <option value="1">Disewa</option>
                                          <option value="2">Kembali</option>
                                      </select>  
                                    </div>

                                    <div class="form-group col-md-3">
                                      <label>Action</label><br>
                                      <button class="btn btn-primary" type="submit">Filter</button>  
                                    </div>
                                </div>
                            </form>
                        </div>
                        <div class="card-body">
                            <?php
                            // Periksa apakah ada parameter yang dikirimkan melalui metode GET
                            if(isset($_GET['sewa']) && isset($_GET['kembali']) && isset($_GET['status'])) {
                                // Ambil nilai dari parameter
                                $tglSewa = $_GET['sewa'];
                                $tglKembali = $_GET['kembali'];
                                $status = $_GET['status'];
                            ?>
                            <a class="btn btn-success" href="cetak_semua.php?sewa=<?php echo $tglSewa; ?>&kembali=<?php echo $tglKembali; ?>&status=<?php echo $status ?>" target="_blank">Cetak Semua</a><br><br>
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No.</th>
                                            <th>Nama Penyewa</th>
                                            <th>Alat Berat</th>
                                            <th>Tgl. Sewa</th>
                                            <th>Tgl. Kembali</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        $no = 1;

                                        $query = mysqli_query($koneksi,"SELECT * FROM tb_sewa, tb_peminjam, tb_alat_berat WHERE idpeminjam = id_peminjam AND idalat = id_alatberat AND tgLpinjam >= '$$tglSewa' AND tgl_kembali <= '$tglKembali' AND status = '$status'");
                                        while ($row = mysqli_fetch_assoc($query)){
                                        ?>
                                        <tr>
                                            <td><?php echo $no++; ?>.</td>
                                            <td><?php echo $row['nama_peminjam']; ?></td>
                                            <td><?php echo $row['nama_alatberat']; ?></td>
                                            <td><?php echo $row['tgLpinjam']; ?></td>
                                            <td><?php echo $row['tgl_kembali']; ?></td>
                                            <td align="center">
                                                <?php if ($row['status'] == 1) { ?>
                                                    <span class="badge badge-primary">Sewa</span>
                                                <?php }elseif ($row['status'] == 2) { ?>
                                                    <span class="badge badge-success">Kembali</span>
                                                <?php } ?>
                                            </td>
                                            <td>
                                                <a class="btn btn-sm btn-warning" href="cetak.php?id=<?php echo $row['id_sewa']; ?>&sewa=<?php echo $tglSewa; ?>&kembali=<?php echo $tglKembali; ?>&status=<?php echo $status ?>" target="_blank">Cetak</a>
                                            </td>
                                        </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                            <?php }else{ ?>
                                <center>
                                    <div class="alert alert-success" role="alert">
                                      Silakan Filter Laporan !
                                    </div>
                                </center>
                            <?php } ?>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Amelia Putri 2020</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="keluar.php">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/datatables-demo.js"></script>

</body>

</html>